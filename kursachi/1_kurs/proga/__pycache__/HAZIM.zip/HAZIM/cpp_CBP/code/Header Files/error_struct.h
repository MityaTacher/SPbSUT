#ifndef ERROR_STRUCT_H_INCLUDED
#define ERROR_STRUCT_H_INCLUDED

struct Error{
    int N;
    double Uvx_parametr;
    double Uvix_parametr;
    double error_rate;
};

#endif // ERROR_STRUCT_H_INCLUDED
